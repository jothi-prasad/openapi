# YanisUserApi.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **Number** |  | 
**userName** | **String** |  | 
**userDescription** | **String** |  | [optional] 
**system** | **String** |  | [optional] 
