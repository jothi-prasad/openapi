# YanisUserApi.Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Number** |  | 
**message** | **String** |  | 
